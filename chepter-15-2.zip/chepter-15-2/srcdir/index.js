// import "./style.css";
import "./style.scss";
// console.log('hello ES6 by ')

const fancyFunc = () => {
  return [1, 2];
};

const [a, b] = fancyFunc();
// console.log(a)